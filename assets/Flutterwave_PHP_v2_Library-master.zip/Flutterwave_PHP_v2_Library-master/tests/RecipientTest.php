<?php
use PHPUnit\Framework\TestCase;

class RecipientTest extends TestCase
{

}

?>
