<?php
use PHPUnit\Framework\TestCase;

class UssdTest extends TestCase
{

}

?>
